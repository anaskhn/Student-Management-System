package com.anas.demo;

import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.MockitoJUnitRunner;

import com.anas.project.Exceptions.StudentNotFoundException;
import com.anas.project.pojo.StudentEntity;
import com.anas.project.repo.StudentRepository;
import com.anas.project.service.StudentServiceImpl;

import static org.junit.jupiter.api.Assertions.*; // For JUnit 5


@RunWith(MockitoJUnitRunner.class)
class StudentServiceImplTest {

    @Mock
    private StudentRepository studentRepoMock;

    @InjectMocks
    private StudentServiceImpl studentService;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.openMocks(this); // Initialize mocks
    }

    @Test
    public void testGetStudentById_found() {
        // Mock behavior for studentRepo
        Integer studentId = 1;
        StudentEntity mockStudent = new StudentEntity("Anas", "Male");
        when(studentRepoMock.findById(studentId)).thenReturn(Optional.of(mockStudent));

        // Service call
        StudentEntity student = studentService.getStudent(studentId);

        // Validate response
        assertNotNull(student);
        assertEquals("Anas", student.getName());
        assertEquals("Male", student.getGender());
    }

    @Test
    public void testGetStudentById_notFound() {
        // Mock behavior for studentRepo
        Integer studentId = 2;
        when(studentRepoMock.findById(studentId)).thenReturn(Optional.empty());

        // Expecting exception
        assertThrows(StudentNotFoundException.class, () -> {
            studentService.getStudent(studentId);
        });
    }

    @Test
    public void testSaveStudent() {
        // Given
        StudentEntity newStudent = new StudentEntity("Anas", "Male");
        when(studentRepoMock.save(newStudent)).thenReturn(newStudent);

        // Service call
        StudentEntity savedStudent = studentService.saveStudent(newStudent);

        // Validate
        assertEquals("Anas", savedStudent.getName());
        assertEquals("Male", savedStudent.getGender());
    }

    @Test
    public void testDeleteStudent() {
        // Given
        Integer studentId = 1;
        doNothing().when(studentRepoMock).deleteById(studentId);

        // Service call
        studentService.deleteStudent(studentId);

        // Verify if delete method was called
        verify(studentRepoMock, times(1)).deleteById(studentId);
    }

    @Test
    public void testGetAllStudents() {
        // Mock some behavior if needed, depending on your repo's return type.
    }
}