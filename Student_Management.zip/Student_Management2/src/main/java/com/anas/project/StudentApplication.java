package com.anas.project;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import com.anas.project.pojo.SubjectEntity;
import com.anas.project.pojo.StudentEntity;
import com.anas.project.repo.SubjectRepository;
import com.anas.project.repo.GradeRepository;
import com.anas.project.repo.StudentRepository;
import com.anas.project.service.SubjectService;
import com.anas.project.service.StudentService;

/**-----------------------------------------------------------------------------------------------------------------
 * 									STUDENT MANAGEMENT SYSTEM														|
 * 																													|
 * This project is focused upon managing Students based on the courses enrolled and Grades obtained.				|
 * You can add, delete, get a student or update an existing one.													|
 * Also add, delete, get a grade or update an existing one,															|
 * and add, delete, get a branch or update an existing one.															|
 * You can also fetch data specific to either of these fields.														|
 * 																													|
 * It contains features such as :																					|
 * 		1. Logging and Unit Testing																					|
 * 		2. Data consistency and integrity																			|
 * 		3. Basic Authentication 																					|
 * 		4. Authorization to selected users																			|
 * 		5. H2 database																								|
 * 																													|
 * @author mohammed.khan																							|
 *																													|
 *------------------------------------------------------------------------------------------------------------------
 */


@SpringBootApplication(scanBasePackages = {"com.anas"})
public class StudentApplication implements CommandLineRunner{
	@Autowired
	StudentRepository studentRepository;

	@Autowired
	GradeRepository gradeRepository;

	@Autowired
	SubjectRepository subjectRepository;
	
	private static final Logger log = LoggerFactory.getLogger(StudentApplication.class);
	
	// To populate H2 with some data every time the application runs
	@Override
	public void run(String... args) throws Exception {
		
		log.info("H2 Database updated!");
		
		StudentEntity[] students = new StudentEntity[] {
	            new StudentEntity("Anas", "Male"),
	            new StudentEntity("Tanish", "Male"),
	            new StudentEntity("Kuldeep", "Male"),
	            new StudentEntity("Monish", "Male") 
	        };
			
			for (int i = 0; i < students.length; i++) {
				studentRepository.save(students[i]);
			}
		
		subjectRepository.save(new SubjectEntity("Computer Science", "COM101", "In this class, you will learn basic coding and technology trends."));
		subjectRepository.save(new SubjectEntity("Information Technology", "IT102", "In this class, you will learn networking and protocols."));
		subjectRepository.save(new SubjectEntity("Electronics and Communications", "ECE103", "In this class, you will learn the study of devices and chips that communicate."));
		subjectRepository.save(new SubjectEntity("Mechanical Tools", "MECH104", "In this class, you will learn about mechanics and engines."));
		subjectRepository.save(new SubjectEntity("Civil and Construction", "CIV105", "In this class, you will learn correct mixing and stirring of ingredients to create mixtures."));
		subjectRepository.save(new SubjectEntity("Artificial Intelligence", "AI106", "In this class, you will learn about Machine Learning and Deep Learning."));
	 
	}

	public static void main(String[] args) {
		SpringApplication.run(StudentApplication.class, args);
	}
	

}
