package com.anas.project.Exceptions;

public class StudentNotFoundException extends RuntimeException { 

    public StudentNotFoundException(Integer id) {
        super("The student id '" + id + "' does not exist in our records");
    }
    
}