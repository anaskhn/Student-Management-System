package com.anas.project.Exceptions;

public class GradeNotFoundException extends RuntimeException { 

    public GradeNotFoundException(Integer studentId, Integer courseId) {
        super("The grade with student id: '" + studentId + "' and course id: '" + courseId + "' does not exist in our records");
    }
    
}