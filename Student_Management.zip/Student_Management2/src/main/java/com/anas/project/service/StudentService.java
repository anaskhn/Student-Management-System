package com.anas.project.service;

import java.util.List;

import com.anas.project.pojo.StudentEntity;

public interface StudentService {

	StudentEntity getStudent(Integer id);

	StudentEntity saveStudent(StudentEntity obj);

	void deleteStudent(Integer id);

	List<StudentEntity> getAllStudents();
}
