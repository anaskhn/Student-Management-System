package com.anas.project.repo;


import com.anas.project.pojo.SubjectEntity;
import org.springframework.data.repository.CrudRepository;


public interface SubjectRepository extends CrudRepository<SubjectEntity, Integer>{
	
}
