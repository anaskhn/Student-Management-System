package com.anas.project.repo;


import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.CrudRepository;

import com.anas.project.pojo.StudentEntity;


public interface StudentRepository extends CrudRepository<StudentEntity, Integer>{
	
}
