package com.anas.project.service;

import java.util.List;

import com.anas.project.pojo.SubjectEntity;
import com.anas.project.pojo.GradeEntity;

public interface GradeService {
	GradeEntity saveGrade(Integer id, GradeEntity grade, Integer branchId);

	GradeEntity getGrade(Integer id, Integer branchId);

	GradeEntity updateGrade(String score, Integer studentId, Integer branchId);

	void deleteGrade(Integer studentId, Integer branchId);

	List<GradeEntity> getStudentGrades(Integer studentId);

	List<GradeEntity> getBranchGrades(Integer branchId);

	List<GradeEntity> getAllGrades();
	
}
