package com.anas.project.pojo;

import java.util.List;

import javax.persistence.*;

import com.fasterxml.jackson.annotation.JsonIgnore;

import lombok.*;

@Data
@RequiredArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "Subject")
public class SubjectEntity {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private Integer id;
	
	@NonNull
	@Column(name = "subject", nullable = false)
	private String subject;
	
	@NonNull
	@Column(name = "code", nullable = false, unique = true)
	private String code;
	
	@NonNull
	@Column(name = "description", nullable = false)
	private String description;

	@JsonIgnore
	@OneToMany(mappedBy = "branch", cascade = CascadeType.ALL)
	private List<GradeEntity> grades;
	
}
