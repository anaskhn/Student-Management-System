package com.anas.project.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.anas.project.StudentApplication;
import com.anas.project.Exceptions.StudentNotFoundException;
import com.anas.project.pojo.GradeEntity;
import com.anas.project.pojo.StudentEntity;
import com.anas.project.repo.StudentRepository;


@Service
public class StudentServiceImpl implements StudentService{
	
	private static final Logger log = LoggerFactory.getLogger(StudentServiceImpl.class);
	
	@Autowired
	StudentRepository studentRepo;
	
	@Override
	public StudentEntity getStudent(Integer id) {
		Optional<StudentEntity> student = studentRepo.findById(id);
		if(student.isPresent()) {
			return student.get();
		}
		else {
			log.error("Error! Student Not Found!");
			throw new StudentNotFoundException(id);
		}
	}
	
	@Override
	public StudentEntity saveStudent(StudentEntity obj) {
		return studentRepo.save(obj);
	}
	
	@Override
	public void deleteStudent(Integer id) {
		studentRepo.deleteById(id);;
	}
	
	@Override
	public List<StudentEntity> getAllStudents() {
		return (List<StudentEntity>)studentRepo.findAll();
	}
	
}
