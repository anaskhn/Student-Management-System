package com.anas.project.Controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.anas.project.StudentApplication;
import com.anas.project.pojo.SubjectEntity;
import com.anas.project.service.SubjectService;

import lombok.AllArgsConstructor;

@AllArgsConstructor
@RestController
@RequestMapping("/subject")
public class SubjectController {
	@Autowired
	SubjectService subjectService;
	
	private static final Logger log = LoggerFactory.getLogger(SubjectController.class);
	
	@PostMapping
	public ResponseEntity<SubjectEntity> saveBranch(@RequestBody SubjectEntity subjectEntity) {
		log.info("Saved a new Branch..");
		return new ResponseEntity<>(subjectService.saveBranch(subjectEntity), HttpStatus.CREATED);
	}
	
	@DeleteMapping("/{id}")
	public ResponseEntity<HttpStatus> deleteBranch(@PathVariable Integer id) {
		log.info("Deleted a Branch..");
		subjectService.deleteBranch(id);
		return new ResponseEntity<>(HttpStatus.NO_CONTENT);
	}
	
	@GetMapping("/all")
	public ResponseEntity<List<SubjectEntity>> getAllBranches(){
		log.info("Fetched All Branches..");
		return new ResponseEntity<>(subjectService.getAllBranches(), HttpStatus.OK);
	}
	
	@GetMapping("/{id}")
	public ResponseEntity<SubjectEntity> getBranchById(@PathVariable Integer id){
		log.info("Fetched a Branch..");
		return new ResponseEntity<>(subjectService.getBranch(id), HttpStatus.OK);
	}
}
