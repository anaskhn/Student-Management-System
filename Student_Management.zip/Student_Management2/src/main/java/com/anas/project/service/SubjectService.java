package com.anas.project.service;

import java.util.List;

import com.anas.project.pojo.SubjectEntity;

public interface SubjectService {

	SubjectEntity getBranch(Integer id);

	SubjectEntity saveBranch(SubjectEntity branch);

	void deleteBranch(Integer id);

	List<SubjectEntity> getAllBranches();
	
}
