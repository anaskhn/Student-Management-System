package com.anas.project.pojo;

import javax.persistence.*;

import lombok.*;

@Data
@Entity
@AllArgsConstructor
@NoArgsConstructor
@Table(name = "grades", uniqueConstraints = {
	    @UniqueConstraint(columnNames = {"studentId", "branchId"})})

public class GradeEntity {
	
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Integer id;
    
    @Column(name = "score", nullable = false)
    private String score;    

    @ManyToOne(optional = false)
    @JoinColumn(name = "studentId", referencedColumnName = "id")
    private StudentEntity student;

    @ManyToOne(optional = false)
    @JoinColumn(name = "branchId", referencedColumnName = "id")
    private SubjectEntity branch;
	
}
