package com.anas.project.Controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;

import com.anas.project.StudentApplication;
import com.anas.project.pojo.GradeEntity;
import com.anas.project.service.GradeService;

import lombok.AllArgsConstructor;

@AllArgsConstructor
@RestController
@RequestMapping("/grade")
public class GradeController {
	
	private static final Logger log = LoggerFactory.getLogger(GradeController.class);
	
	@Autowired
	GradeService gradeService;
	
	
	@GetMapping("/student/{studentId}/branch/{branchId}")
    public ResponseEntity<GradeEntity> getGrade(@PathVariable Integer studentId, @PathVariable Integer branchId) {
		log.info("Fetched a Grade..");
        return new ResponseEntity<>(gradeService.getGrade(studentId, branchId), HttpStatus.OK);
    }

    @PostMapping("/student/{studentId}/branch/{branchId}")
    public ResponseEntity<GradeEntity> saveGrade(@RequestBody GradeEntity grade, @PathVariable Integer studentId, @PathVariable Integer branchId) {
    	log.info("Saved a Grade..");
        return new ResponseEntity<>(gradeService.saveGrade(studentId, grade, branchId), HttpStatus.CREATED);
    }

    @PutMapping("/student/{studentId}/branch/{branchId}")
    public ResponseEntity<GradeEntity> updateGrade(@RequestBody GradeEntity grade, @PathVariable Integer studentId, @PathVariable Integer branchId) {
    	log.info("Updated a Grade..");
        return new ResponseEntity<>(gradeService.updateGrade(grade.getScore(), studentId, branchId), HttpStatus.OK);
    }

    @DeleteMapping("/student/{studentId}/branch/{branchId}")
    public ResponseEntity<HttpStatus> deleteGrade(@PathVariable Integer studentId, @PathVariable Integer branchId) {
    	log.info("Deleted a Grade..");
        gradeService.deleteGrade(studentId, branchId);
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }

    @GetMapping("/student/{studentId}")
    public ResponseEntity<List<GradeEntity>> getStudentGrades(@PathVariable Integer studentId) {
    	log.info("Fetched a Grade by Student ID..");
        return new ResponseEntity<>(gradeService.getStudentGrades(studentId), HttpStatus.OK);
    }

    @GetMapping("/branch/{branchId}")
    public ResponseEntity<List<GradeEntity>> getBranchGrades(@PathVariable Integer branchId) {
    	log.info("Fetched a Grade by Branch ID..");
        return new ResponseEntity<>(gradeService.getBranchGrades(branchId), HttpStatus.OK);
    }

    @GetMapping("/all")
    public ResponseEntity<List<GradeEntity>> getGrades() {
    	log.info("Fetched all Grades..");
        return new ResponseEntity<>(gradeService.getAllGrades(), HttpStatus.OK);
    }
}
