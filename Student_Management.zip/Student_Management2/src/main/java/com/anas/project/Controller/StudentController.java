package com.anas.project.Controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.method.annotation.MethodArgumentTypeMismatchException;

import com.anas.project.StudentApplication;
import com.anas.project.pojo.StudentEntity;
import com.anas.project.service.StudentService;

import lombok.AllArgsConstructor;

@AllArgsConstructor
@RestController
@RequestMapping("/student")
public class StudentController {
	
	private static final Logger log = LoggerFactory.getLogger(StudentController.class);
	
	@Autowired
    StudentService studentService;
	
	
	@GetMapping("/{id}")
    public ResponseEntity<StudentEntity> getStudent(@PathVariable Integer id) {
		log.info("Fetched a Student..");
        return new ResponseEntity<>(studentService.getStudent(id), HttpStatus.OK);
    }
    
    @PostMapping("/save")
    public ResponseEntity<StudentEntity> saveStudent(@RequestBody StudentEntity obj) {
    	log.info("Saved a Student..");
    	StudentEntity result = studentService.saveStudent(obj);
        return ResponseEntity.ok(result);
    }
    
    @DeleteMapping("/{id}")
    public ResponseEntity<HttpStatus> deleteStudent(@PathVariable Integer id) {
    	log.info("Deleted a Student..");
    	studentService.deleteStudent(id);
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }
    
    @GetMapping("/all")
    public ResponseEntity<List<StudentEntity>> getAllStudents() {
    	log.info("Fetched all Students..");
        return new ResponseEntity<>(studentService.getAllStudents(), HttpStatus.OK);
    }
    
    @PutMapping("/update/{id}")
    public ResponseEntity<StudentEntity> updateStudents(@RequestBody StudentEntity newObject, @PathVariable Integer id) {
    	log.info("Updated a Student..");
        StudentEntity previousObject = studentService.getStudent(id);
        
        if (previousObject == null) {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }

        previousObject.setGender(newObject.getGender());
        previousObject.setName(newObject.getName());
        studentService.saveStudent(previousObject);

        return new ResponseEntity<>(previousObject, HttpStatus.ACCEPTED);
    }

}
