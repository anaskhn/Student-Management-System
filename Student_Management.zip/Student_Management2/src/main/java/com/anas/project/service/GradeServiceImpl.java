package com.anas.project.service;

import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.anas.project.StudentApplication;
import com.anas.project.Exceptions.GradeNotFoundException;
import com.anas.project.pojo.SubjectEntity;
import com.anas.project.pojo.GradeEntity;
import com.anas.project.pojo.StudentEntity;
import com.anas.project.repo.SubjectRepository;
import com.anas.project.repo.GradeRepository;
import com.anas.project.repo.StudentRepository;

import lombok.AllArgsConstructor;

@AllArgsConstructor
@Service
public class GradeServiceImpl implements GradeService{
	GradeRepository gradeRepo;
	StudentRepository dataRepo;
	SubjectRepository branchRepo;
	
	private static final Logger log = LoggerFactory.getLogger(GradeServiceImpl.class);
	
	@Override
	public GradeEntity getGrade(Integer studentId, Integer branchId) {
		Optional<GradeEntity> grade = gradeRepo.findByStudentIdAndBranchId(studentId, branchId);
		if(grade.isPresent()) {
			return grade.get();
		}
		else {
			log.error("Error! Grade Not Found!");
			throw new GradeNotFoundException(studentId, branchId);
		}
	}
	
	@Override
	public GradeEntity saveGrade(Integer id, GradeEntity grade, Integer branchId) {
		Optional<StudentEntity> studentEntity = dataRepo.findById(id);
		Optional<SubjectEntity> branch = branchRepo.findById(branchId);
		if(studentEntity.isPresent() && branch.isPresent()) {
			grade.setStudent(studentEntity.get());
			grade.setBranch(branch.get());
			return gradeRepo.save(grade);
		}
		else {
			log.error("Error! Grade Not Found!");
			throw new GradeNotFoundException(id, branchId);
		}
	}

	@Override
	public GradeEntity updateGrade(String score, Integer studentId, Integer branchId) {
		Optional<GradeEntity> grade = gradeRepo.findByStudentIdAndBranchId(studentId, branchId);
		if(grade.isPresent()) {
			GradeEntity unwrappedGrade = grade.get();
			unwrappedGrade.setScore(score);
			return gradeRepo.save(unwrappedGrade);
		}
		else {
			log.error("Error! Grade Not Found!");
			throw new GradeNotFoundException(studentId, branchId);
		}
	}

	@Override
	public void deleteGrade(Integer studentId, Integer branchId) {
		gradeRepo.deleteByStudentIdAndBranchId(studentId, branchId);
	}

	@Override
	public List<GradeEntity> getStudentGrades(Integer studentId) {
		return gradeRepo.findByStudentId(studentId);
	}

	@Override
	public List<GradeEntity> getBranchGrades(Integer branchId) {
		return gradeRepo.findByBranchId(branchId);
	}

	@Override
	public List<GradeEntity> getAllGrades() {
		return (List<GradeEntity>) gradeRepo.findAll();
	}
}
