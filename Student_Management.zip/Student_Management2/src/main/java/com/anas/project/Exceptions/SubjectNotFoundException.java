package com.anas.project.Exceptions;

public class SubjectNotFoundException extends RuntimeException { 

    public SubjectNotFoundException(Integer id) {
        super("The subject id '" + id + "' does not exist in our records");
    }
    
}