package com.anas.project.service;

import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.anas.project.StudentApplication;
import com.anas.project.Exceptions.SubjectNotFoundException;
import com.anas.project.pojo.SubjectEntity;
import com.anas.project.repo.SubjectRepository;

import lombok.Data;

@Data
@Service
public class SubjectServiceImpl implements SubjectService{
	
	private static final Logger log = LoggerFactory.getLogger(SubjectServiceImpl.class);
	
	@Autowired
	SubjectRepository branchRepo;
	
	@Override
	public SubjectEntity getBranch(Integer id) {
		Optional<SubjectEntity> branch = branchRepo.findById(id);
		if(branch.isPresent()) {
			return branch.get();
		}
		else {
			log.error("Error! Branch Not Found!");
			throw new SubjectNotFoundException(id);
		}
	}
	
	@Override 
	public SubjectEntity saveBranch(SubjectEntity branch) {
		return branchRepo.save(branch);
	}
	
	@Override 
	public void deleteBranch(Integer id) {
		branchRepo.deleteById(id);;
	}
	
	@Override 
	public List<SubjectEntity> getAllBranches() {
		return (List<SubjectEntity>) branchRepo.findAll();
	}
	
}
