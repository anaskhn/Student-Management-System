
# Student Management System

The system allows users to manage student records via RESTful APIs. It implements CRUD operations for students, along with simple data validation and is secured by Basic Authentication.
This system uses H2 database.




## API Reference

### **Students :**
#### Get all Students

```http
  GET /student/all
```

#### Get Student by ID

```http
  GET /student/{id}
```

| Parameter | Type     | Description                       |
| :-------- | :------- | :-------------------------------- |
| `id`      | `string` | Id of Student to fetch            |

#### Add a new Student

```http
  POST /student/save
```

| Request Body | Type     | Description                       |
| :----------- | :------- | :-------------------------------- |
| Student      | `JSON`   | Student data to add               |

#### Update existing Student

```http
  PUT /student/update/{id}
```
| Parameter | Type     | Description                       |
| :-------- | :------- | :-------------------------------- |
| `id`      | `string` | Id of Student to update           |

| Request Body | Type     | Description                    |
| :----------- | :------- | :----------------------------- |
| Student      | `JSON`   | Student data to update         |

#### Delete a Student

```http
  DELETE /student/{id}
```

| Parameter | Type     | Description                       |
| :-------- | :------- | :-------------------------------- |
| `id`      | `string` | Id of Student to Delete           |

### **Grades :**
#### This is a common path to the following requests:
```http
/grades/student/{studentId}/branch/{branchId}
```
| Parameter        | Type     | Description         |
| :--------------- | :------- | :------------------ |
| `studentId`      | `string` | Id of Student       |
| `branchId`       | `string` | Id of Branch        |

#### Get Grades by Student Id and Branch Id
```http
  GET /grades/student/{studentId}/branch/{branchId}
```

#### Add Grade to a Student in a Branch

```http
  POST /grades/student/{studentId}/branch/{branchId}
```
| Request Body | Type     | Description             |
| :----------- | :------- | :---------------------- |
| Grade        | `JSON`   | Grade data to Add       |

#### Update existing Grade

```http
  PUT /grades/student/{studentId}/branch/{branchId}
```
| Request Body | Type     | Description                 |
| :----------- | :------- | :-------------------------- |
| Grade        | `JSON`   | Grade data to update        |

#### Delete a Grade

```http
  DELETE /grades/student/{studentId}/branch/{branchId}
```

#### Get Grades by Student Id only
```http
  GET /grades/student/{studentId}
```

#### Get Grades by Branch Id only
```http
  GET /grades/branch/{branchId}
```


#### Get all Grades
```http
  GET /grades/all
```

### **Branch :**
#### Get Branch by ID
```http
  GET /branch/{id}
```
| Parameter | Type     | Description                       |
| :-------- | :------- | :-------------------------------- |
| `id`      | `string` | Id of Branch to fetch             |

#### Get all Branches
```http
  GET /branch/all
```

#### Delete Branch by ID

```http
  DELETE /branch/{id}
```
| Parameter | Type     | Description                       |
| :-------- | :------- | :-------------------------------- |
| `id`      | `string` | Id of Branch to delete            |

#### Add a new branch

```http
  POST /branch
```
| Request Body | Type     | Description                 |
| :----------- | :------- | :-------------------------- |
| Branch       | `JSON`   | Branch data to add          |